"""
App package initialization
"""
